#include<iostream>
using namespace std;
int main(){
	char operation;
	float num1,num2;
	cout<<"enter any operation:+,_,*,\,sin,cos,tan:"<<endl;
	cin>>operation;
	cout<<"enter two operand:"<<endl;
	cin>>num1>>num2;
	switch (operation)
	{
		case '+':
		cout<<num1<<"+"<<num2<<"="<<num1+num2;
		break;
			case '-':
		cout<<num1<<"-"<<num2<<"="<<num1-num2;
		break;
			case '*':
		cout<<num1<<"*"<<num2<<"="<<num1*num2;
		break;
			case '/':
		cout<<num1<<"/"<<num2<<"="<<num1/num2;
		break;
		case 'sin':
		cout<<num1<<"sin"<<num2"="<<num1sin num2;
		break;
			cout<<num1<<"cos"<<num2"="<<num1cos num2;
		break;
			cout<<num1<<"tan"<<num2"="<<num1tan num2;
		break;
					cout<<num1<<"tan"<<num2"="<<num1tan num2;
		break;
		default:
			cout<<"Error!operator is not correct:"<<endl;
}
return 0;
}