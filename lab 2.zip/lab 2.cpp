#include<iostream>
using namespace std;

int main(){
	int time=(hours,mins,secs);
cout<<"enter time of first sitting"<<endl;
cin>>"total chrges";
cout<<"enter time of second sitting"<<endl;
cin>>"total chrges";
cout<<"enter time of third sitting"<<endl;
cin>>"total chrges";

return 0;
}